fn main() {
    let a: i32 = 10;
    let b: i32 = 5;
    println!("Addition: {}", a + b);
    println!("Subtraction: {}", a - b);
    println!("Multiplication: {}", a * b);
    println!("Division: {}", a / b);
    println!("Modulo: {}", a % b);
}

