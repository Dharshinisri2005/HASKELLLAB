fn main() {
    let integer_var: i32 = 10;
    let float_var: f64 = 3.14;
    let bool_var: bool = true;
    let char_var: char = 'A';
    println!("Integer: {}", integer_var);
    println!("Floating-point: {}", float_var);
    println!("Boolean: {}", bool_var);
    println!("Character: {}", char_var);
}

