fn main() {
    for i in 1..21 {
          println!("{}", i);
    }
}

