fn main() {
    for i in 1..=20 {
        if i % 2 != 0 {
            println!("{}", i);
        } 
    }
}

