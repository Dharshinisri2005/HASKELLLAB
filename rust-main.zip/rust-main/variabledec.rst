fn main(){
   let i : i32 = 123;
   let f : f64 = 123.321;
   let b : bool = true;
   let c : char = 'A';
   println!("{} is an integer value",i);
   println!("{} is an float value",f);
   println!("{} is an boolean value",b);
   println!("{} is an character value",c);
}    
