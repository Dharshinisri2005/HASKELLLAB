fn main() {
    let num1: i32 = 10;
    let num2: i32 = 3;
    let addition = num1 + num2;
    let subtraction = num1 - num2;
    let multiplication = num1 * num2;
    let division = num1 / num2;
    let modulo = num1 % num2;
    println!("Addition: {} + {} = {}", num1, num2, addition);
    println!("Subtraction: {} - {} = {}", num1, num2, subtraction);
    println!("Multiplication: {} * {} = {}", num1, num2, multiplication);
    println!("Division: {} / {} = {}", num1, num2, division);
    println!("Modulo: {} % {} = {}", num1, num2, modulo);
}

