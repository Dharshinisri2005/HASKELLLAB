fn main() {
    for num in 1..=20 {
        if num % 2 == 0 {
            println!("{}", num);
        }
    }
}

