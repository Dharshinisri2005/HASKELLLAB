fn main() {
    for num in (1..=10).rev() {
        println!("{}", num);
    }
}

